var env={};
env.AUTH0_SECRET='YOUR AUTH0 SECRET HERE';
module.exports = env;
