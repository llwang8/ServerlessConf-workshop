var env={};
env.AUTH0_DOMAIN='YOUR AUTH0 DOMAIN HERE';
module.exports = env;
