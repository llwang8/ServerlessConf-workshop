var env={};
env.ELASTIC_TRANSCODER_REGION = 'us-east-1';
env.ELASTIC_TRANSCODER_PIPELINE_ID = 'YOUR PIPELINE ID HERE';
module.exports = env;
