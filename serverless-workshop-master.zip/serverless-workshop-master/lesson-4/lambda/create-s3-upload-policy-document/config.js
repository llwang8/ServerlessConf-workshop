var env={};
env.UPLOAD_BUCKET = 'YOUR UPLOAD BUCKET HERE';
env.SECRET_ACCESS_KEY = 'YOUR IAM USER SECRET ACCESS KEY HERE';
env.ACCESS_KEY = 'YOUR IAM USER KEY HERE';
env.UPLOAD_URI = 'https://s3.amazonaws.com';
module.exports = env;
