var configConstants = {
    auth0: {
        domain: 'YOUR_AUTH0_DOMAIN_HERE',
        clientId: 'YOUR_AUTH0_CLIENT_ID_HERE'
    },
    apiBaseUrl: 'YOUR_API_BASE_URL_HERE_NO_TRAILING_SLASH',
    firebaseUrl: 'YOUR_FIRE_BASE_URL_HERE_NO_TRAILING_SLASH'
};
