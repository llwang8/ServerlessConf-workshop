var env={};
env.BUCKET_REGION = 'us-east-1';
env.FIREBASE_URL = 'YOUR FIREBASE URL HERE';
env.FIREBASE_SECRET = 'YOUR FIREBASE SECRET HERE';
env.S3 = 'https://s3.amazonaws.com/YOUR_TRANSCODED_BUCKET_NAME_HERE';
module.exports = env;
