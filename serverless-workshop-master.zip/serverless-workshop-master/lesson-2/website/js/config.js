var configConstants = {
    auth0: {
        domain: 'YOUR_AUTH0_DOMAIN_HERE',
        clientId: 'YOUR_AUTH0_CLIENT_ID_HERE'
    }
};
